import { Component ,OnInit} from "@angular/core";
import {BookService} from'./app.BookService';
@Component({
    selector:'add-comp',
    templateUrl:'addbook.html'
})
export class AddBookComponent implements OnInit{
    
    constructor(private service:BookService){}
    bookAll:any[]=[];
    ngOnInit(){
        this.service.getAllBooks().subscribe((data:any)=>this.bookAll=data);
    }
    deleteEmployee(data:number):any{
        this.bookAll.splice(data,1);
        alert('Data Deleted');
        
      }
}