"use strict";
exports.__esModule = true;
var Mobile_1 = require("./Mobile");
var emp = new Mobile_1.Mobile();
emp.printMobileDetail(101, "LG", 2500, "BasicPhone");
var emp1 = new Mobile_1.Mobile();
emp1.printMobileDetail(102, "Sumsung", 2500, "SmartPhone");
