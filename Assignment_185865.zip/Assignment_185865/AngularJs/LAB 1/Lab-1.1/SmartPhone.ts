export class Smart{
   
    MobileType:string;
   
   
    static printType():any{
        return "SmartPhone";
    }
}